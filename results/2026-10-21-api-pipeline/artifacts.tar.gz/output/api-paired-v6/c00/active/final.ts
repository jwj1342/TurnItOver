import type * as THREE from "three";

type JointKind = "revolute" | "prismatic";

interface JointHandle {
  type: JointKind;
  part: string;
  limits: [number, number];
  set(value: number): void;
}

interface ArticulatedObject {
  root: THREE.Object3D;
  joints: Record<string, JointHandle>;
  dispose?(): void;
}

export default function createObject(THREE: typeof THREE): ArticulatedObject {
  const root = new THREE.Group();
  root.name = "root";

  const makePart = (
    name: string,
    size: [number, number, number],
    center: [number, number, number],
    color: number
  ): THREE.Group => {
    const group = new THREE.Group();
    group.name = name;
    group.position.set(center[0], center[1], center[2]);

    const geometry = new THREE.BoxGeometry(size[0], size[1], size[2]);
    const material = new THREE.MeshStandardMaterial({
      color,
      roughness: 1,
      metalness: 0
    });
    const mesh = new THREE.Mesh(geometry, material);
    mesh.name = `${name}_mesh`;
    group.add(mesh);

    return group;
  };

  const base = makePart("base", [1, 0.1, 0.6], [0, 0.05, 0], 0xb08a5a);
  root.add(base);

  const drawerSlide = new THREE.Group();
  drawerSlide.name = "joint:drawer_slide";
  drawerSlide.position.set(0, 0, 0);
  root.add(drawerSlide);

  const drawer = makePart("drawer", [0.4, 0.2, 0.4], [-0.25, 0.25, 0], 0x5a7fb0);
  drawerSlide.add(drawer);

  const doorHinge = new THREE.Group();
  doorHinge.name = "joint:door_hinge";
  doorHinge.position.set(0.05, 0.4, 0.22);
  root.add(doorHinge);

  const door = makePart("door", [0.4, 0.5, 0.04], [0.2, 0, 0], 0x8a5a5a);
  doorHinge.add(door);

  const joints: Record<string, JointHandle> = {
    drawer_slide: {
      type: "prismatic",
      part: "drawer",
      limits: [0, 0.3],
      set(value: number): void {
        const v = THREE.MathUtils.clamp(Number(value) || 0, 0, 0.3);
        drawerSlide.position.set(0, 0, v);
      }
    },
    door_hinge: {
      type: "revolute",
      part: "door",
      limits: [0, Math.PI / 2],
      set(value: number): void {
        const v = THREE.MathUtils.clamp(Number(value) || 0, 0, Math.PI / 2);
        doorHinge.rotation.set(0, -v, 0);
      }
    }
  };

  const dispose = (): void => {
    root.traverse((object: THREE.Object3D) => {
      const mesh = object as THREE.Mesh;
      if (mesh.isMesh) {
        mesh.geometry.dispose();
        const material = mesh.material as THREE.Material | THREE.Material[];
        if (Array.isArray(material)) {
          for (const item of material) item.dispose();
        } else {
          material.dispose();
        }
      }
    });
  };

  return { root, joints, dispose };
}
