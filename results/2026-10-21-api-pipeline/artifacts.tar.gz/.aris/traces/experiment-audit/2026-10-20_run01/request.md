# Fresh experiment integrity audit request

Date: 2026-10-20
Reviewer agent: `/root/integrity_audit`
Reviewer configuration supplied by the spawning parent: `gpt-6-astra`, reasoning `ultra`, `fork_turns=none`.
Review independence: `same-family`; acceptance status: `provisional`.

Read the implementation and artifacts directly. Trust no outcome claims. Check:

- A: whether ground truth is an independently authored reference or model output;
- B: score denominators and raw metric availability;
- C: result existence and exact numerical claims;
- D: whether scoring functions were reached, including failure paths;
- E: actual object, case, sample and run scope;
- F: evaluation classification and the distinction between real model runs and scripted-response real-browser integration tests.

Initial implementation inputs:

- `turnitover/api_pipeline/{fixture,paired,scoring,api}.py`
- `scripts/run_api_pipeline.py`
- `turnitover/repair/iterative.py`
- `turnitover/verifier/{runner,policies,loop,gt_validator}.py`
- `turnitover/models/client.py`
- `docs/api-pipeline.md`
- `docs/api-pipeline-code-review.md`
- `docs/api-pipeline-report.md` once written
- `tests/browser/test_api_pipeline.py`
- `tests/browser/test_api_pipeline_roundtrip.py`
- `tests/unit/test_api_recording.py`
- `tests/unit/test_api_pipeline_scoring.py`
- `tests/unit/test_verifier_exact_budget.py`
- `output/api-prepared-v1/`, its adjacent API ledger and request/error records
- `logs/api-prepare-v1.log`, `logs/api-unit-tests.log`, `logs/api-paired-fixture-tests.log`

Expanded scope supplied during the audit:

- Include `output/api-diagnostic-v1-api/`; distinguish the exact diagnostic replay from the first failed generation.
- Include the successful temperature-1 preparation in `output/api-prepared-v2/` and its adjacent API ledger.
- Include the interrupted `output/api-minimal-v2/` and the old-build engineering debugging run `output/api-minimal-v3/`; count their requests and available usage separately.
- Review `web/src/harness.ts` and `tests/browser/test_part_handles.py`. Verify that logical part handles exclude Mesh names, consistently with the existing Program ABI validation.
- Wait for the new browser build, subsequent formal paired artifacts and final report before issuing a final verdict.
- Review runtime build hashes and the repaired serialized-action replay interface.

Continuation of the same audit on 2026-10-21:

- Audit `output/api-minimal-v4/`, whose 4096-token final diagnosis was truncated, including the failed response's reported usage.
- Audit `output/api-minimal-v5/`, whose actual model diagnosed and repaired the door-axis fault, then encountered HTTP 524 at the final decision of its fresh second verifier round.
- Review `turnitover/models/streaming.py`, `turnitover/api_pipeline/recovery.py`, and their tests. SSE is a transport change; retain actual wire bytes, completion checks, model identity, and provider usage.
- Review the proposed `output/api-minimal-v6/` segmented continuation: retain v5 unchanged and incomplete; retry only the failed final decision using the identical saved prompt and image bytes; acquire no new Active observations or repairs; then execute Fixed for the first time from the shared initial program.
- Require source provenance, source/candidate/runtime/configuration checks, an explicit continuation label, and cost deduplication across the old and new ledgers.
- Include the subsequent first-run c00/c01 streamed pair, if executed, and the final report. Do not pool different output-cap or runtime configurations as one uninterrupted frozen experiment.

Auditor restrictions: issue no API requests; edit no implementation; write only audit and trace artifacts. Do not reproduce credentials or endpoint values. Preserve and distinguish the first failed integration test from its corrected rerun.

Required outputs:

- `docs/api-pipeline-audit.md`
- `docs/api-pipeline-audit.json`
- `.aris/traces/experiment-audit/2026-10-20_run01/{request.md,response.md,metadata.json}`

Include audited input SHA-256 hashes, `agent_id`, `verdict_id`, `review_independence: same-family` and `acceptance_status: provisional`. Report actual generation, candidate rendering, verification and repair completion separately.
